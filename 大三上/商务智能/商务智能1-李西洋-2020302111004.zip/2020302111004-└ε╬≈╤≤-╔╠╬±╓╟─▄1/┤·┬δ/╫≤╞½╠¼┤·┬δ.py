import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

shape, scale = 2., 3.
s = np.random.gamma(shape, scale, 2000) / 20 + 0.001

plt.hist(s, 50)
plt.show()
s = pd.Series(s)
print(s)
print("**********")
print("偏度：")
print(s.skew(), end='\n')
print("峰度：")
print(s.kurt(), end='\n')
