# 思路
# 拿到页面源代码
# 编写正则表达式
# 保存数据
import re

import requests

# 建立保存文件
f = open("top25.csv", mode="w", encoding='utf-8')

# 建立与网页的连接
url = "https://movie.douban.com/top250"
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 Edg/106.0.1370.37"
}
resp = requests.get(url, headers=headers)

# 获取页面源代码
pageSource = resp.text

# 构建正则表达式，获取想要的数据
obj = re.compile(r'<div class="item">.*?<span class="title">(?P<name>.*?)</span>.*?导演: (?P<director>.*?)&nbsp;.*?'
                 r'<br>(?P<year>.*?)&nbsp;/&nbsp;(?P<country>.*?)&nbsp;.*?<span class="rating_num" property="v:aver'
                 r'age">(?P<score>.*?)</span>.*?<span>(?P<peoNum>.*?)人评价</span>', re.S)
result = obj.finditer(pageSource)

# 将数据保存至。csv文件中
for item in result:
    name = item.group("name")
    director = item.group("director")
    year = item.group("year").strip()
    country = item.group("country")
    score = item.group("score")
    peoNum = item.group("peoNum")
    f.write(f"{name},{director},{year},{country},{score},{peoNum}\n")

# 关闭连接
f.close()
resp.close()
print("提取完毕")
