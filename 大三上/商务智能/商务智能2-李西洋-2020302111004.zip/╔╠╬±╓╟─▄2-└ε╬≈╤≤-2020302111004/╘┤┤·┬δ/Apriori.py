# 加载候选项集
def load_data_set():
    data_set = [['d1', 'd2'], ['d2', 'd3', 'd5'], ['d1', 'd3'],
                ['d1', 'd2', 'd4'], ['d3', 'd4'], ['d2', 'd3'],
                ['d2', 'd5'], ['d1', 'd2', 'd3', 'd5'], ['d1', 'd3', 'd4']]
    return data_set


# 生成候选1项集
def create_C1(data_set):
    C1 = set()  # set():生成无序不重复元素集
    for t in data_set:  # 遍历data_set
        for item in t:  # 取出元素
            item_set = frozenset([item])  # frozenset():生成冻结的集合
            C1.add(item_set)
    return C1


# 判断连接是否正确
# Ck_item:候选k项集中的一个元素
# Lksub1:频繁k-1项集
def is_apriori(Ck_item, Lksub1):
    for item in Ck_item:
        sub_Ck = Ck_item - frozenset([item])
        if sub_Ck not in Lksub1:
            return False
    return True


# 由L(k-1)生成C(k)
# Ck_item:候选k项集
# Lksub1:频繁k-1项集
def create_Ck(Lksub1, k):
    Ck = set()  # 将Ck设置为不可重复集
    len_Lksub1 = len(Lksub1)
    list_Lksub1 = list(Lksub1)
    for i in range(len_Lksub1):  # range()生成[0,len)的整数序列
        for j in range(1, len_Lksub1):
            l1 = list(list_Lksub1[i])
            l2 = list(list_Lksub1[j])
            l1.sort()  # sort()排序
            l2.sort()
            # 判断是否有相同部分
            if l1[0:k - 2] == l2[0:k - 2]:
                # 进行连接运算，相同部分只留下一个，如{'l1', 'l5'} | {'l1', 'l3'} = {'l1', 'l3', 'l5'}
                Ck_item = list_Lksub1[i] | list_Lksub1[j]
                # pruning
                # 判断连接是否由L(k-1)产生
                if is_apriori(Ck_item, Lksub1):
                    Ck.add(Ck_item)
    return Ck


# 对C(k)执行删除策略，生成L(K)项集
# data_set:原始数据集
def generate_Lk_by_Ck(data_set, Ck, min_support, support_data):
    Lk = set()
    item_count = {}
    # 进行计数操作，判断元素是否被包含在原始数据集中，是就+1
    for t in data_set:
        for item in Ck:
            if item.issubset(t):  # 判断item集合的所有元素是否都包含在t中
                if item not in item_count:
                    item_count[item] = 1
                else:
                    item_count[item] += 1
    # 满足最小支持度的元素进入L(k)
    for item in item_count:
        if item_count[item] >= min_support:
            Lk.add(item)
            support_data[item] = item_count[item]
    return Lk


# 生成频繁项集
def generate_L(data_set, k, min_support):
    support_data = {}
    # 生成C1
    C1 = create_C1(data_set)
    # 生成L1
    L1 = generate_Lk_by_Ck(data_set, C1, min_support, support_data)
    Lksub1 = L1.copy()
    L = []
    L.append(Lksub1)
    # 由L(k-1)生成C(k),再由C(k)生成L(k)
    for i in range(2, k + 1):
        Ci = create_Ck(Lksub1, i)
        Li = generate_Lk_by_Ck(data_set, Ci, min_support, support_data)
        Lksub1 = Li.copy()
        L.append(Lksub1)  # 将所有频繁项加入L中
    return L, support_data


# 生成最大关联规则
# L包含所有频繁项
# support_data为相应支持度数据
def generate_big_rules(L, support_data, min_conf):
    big_rule_list = []
    sub_set_list = []
    for i in range(0, len(L)):
        for freq_set in L[i]:
            for sub_set in sub_set_list:
                # 判断sub_set是否在freq_set中
                if sub_set.issubset(freq_set):
                    conf = support_data[freq_set] / support_data[freq_set - sub_set]
                    big_rule = (freq_set - sub_set, sub_set, conf)
                    if conf >= min_conf and big_rule not in big_rule_list:
                        # print freq_set-sub_set, " => ", sub_set, "conf: ", conf
                        big_rule_list.append(big_rule)
            sub_set_list.append(freq_set)
    return big_rule_list


if __name__ == "__main__":
    data_set = load_data_set()
    L, support_data = generate_L(data_set, k=3, min_support=2)
    big_rules_list = generate_big_rules(L, support_data, min_conf=0.8)
    i = 0
    for Lk in L:
        i = i + 1
        print("=" * 50)
        print("frequent " + str(i) + "-itemsets\t\t支持度")
        print("=" * 50)
        for freq_set in Lk:
            print(freq_set, support_data[freq_set])
    print()
    print("关联规则：")
    for item in big_rules_list:
        print(item[0], "=>", item[1], "conf: ", item[2])
