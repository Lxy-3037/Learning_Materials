# 加载数据
def loadSimpDat():
    simpDat = [['d1', 'd2'], ['d2', 'd3', 'd5'], ['d1', 'd3'],
               ['d1', 'd2', 'd4'], ['d3', 'd4'], ['d2', 'd3'],
               ['d2', 'd5'], ['d1', 'd2', 'd3', 'd5'], ['d1', 'd3', 'd4']]
    return simpDat


# 将数据集转化为目标格式
def createInitSet(dataSet):
    retDict = {}
    for trans in dataSet:
        fset = frozenset(trans)
        retDict.setdefault(fset, 0)
        retDict[fset] += 1
    return retDict


# 树结构定义
class treeNode:
    def __init__(self, nameValue, numOccur, parentNode):
        self.name = nameValue  # 节点元素名称，在构造时初始化为给定值
        self.count = numOccur  # 出现次数，在构造时初始化为给定值
        self.nodeLink = None  # 指向下一个相似节点的指针，默认为None
        self.parent = parentNode  # 指向父节点的指针，在构造时初始化为给定值
        self.children = {}  # 指向子节点的字典，以子节点的元素名称为键，指向子节点的指针为值，初始化为空字典

    # 增加节点的出现次数值
    def inc(self, numOccur):
        self.count += numOccur

    # 输出节点和子节点的FP树结构
    def disp(self, ind=1):
        print(' ' * ind, self.name, ' ', self.count)
        for child in self.children.values():
            child.disp(ind + 1)


def createTree(dataSet, minSup=2):
    headerTable = {}
    # 第一次遍历数据集，创建头指针表
    headerTable = {}
    for trans in dataSet:
        for item in trans:
            headerTable[item] = headerTable.get(item, 0) + dataSet[trans]
    # 根据最小支持度过滤
    keys = list(headerTable.keys())  # 因为字典要求在迭代中不能修改，所以转化为列表
    for k in keys:
        if headerTable[k] < minSup:
            del (headerTable[k])
    freqItemSet = set(headerTable.keys())
    # 如果所有数据都不满足最小支持度，返回None, None
    if len(freqItemSet) == 0:
        return None, None
    for k in headerTable:
        headerTable[k] = [headerTable[k], None]
    retTree = treeNode('φ', 1, None)
    # 第二次遍历数据集，构建fp-tree
    for tranSet, count in dataSet.items():
        # 根据最小支持度处理一条训练样本，key:样本中的一个样例，value:该样例的的全局支持度
        localD = {}  # 记录频繁1项集的全局频率，用于排序
        for item in tranSet:
            if item in freqItemSet:  # 只考虑频繁项
                localD[item] = headerTable[item][0]
        if len(localD) > 0:
            # 根据全局频繁项对每个事务中的数据进行排序
            orderedItems = [v[0] for v in sorted(localD.items(), key=lambda p: (p[1], p[0]), reverse=True)]  # 排序
            updateTree(orderedItems, retTree, headerTable, count)  # 更新FP树
    return retTree, headerTable


# 对不是第一个出现的节点，更新头指针块。就是添加到相似元素链表的尾部
def updateHeader(nodeToTest, targetNode):  # this version does not use recursion
    while nodeToTest.nodeLink is not None:  # Do not use recursion to traverse a linked list!
        nodeToTest = nodeToTest.nodeLink
    nodeToTest.nodeLink = targetNode


# 根据一个排序过滤后的频繁项更新FP树
def updateTree(items, inTree, headerTable, count):
    if items[0] in inTree.children:
        # 根据一个排序过滤后的频繁项更新FP树
        inTree.children[items[0]].inc(count)  # increment count
    else:
        # 没有这个元素项时创建一个新节点
        inTree.children[items[0]] = treeNode(items[0], count, inTree)
        # 更新头指针表或前一个相似元素项节点的指针指向新节点
        if headerTable[items[0]][1] is None:
            headerTable[items[0]][1] = inTree.children[items[0]]
        else:
            updateHeader(headerTable[items[0]][1], inTree.children[items[0]])

    if len(items) > 1:
        # 更新头指针表或前一个相似元素项节点的指针指向新节点
        updateTree(items[1:], inTree.children[items[0]], headerTable, count)


# 直接修改prefixPath的值，将当前节点leafNode添加到prefixPath的末尾，然后递归添加其父节点。
# prefixPath就是一条从treeNode（包括treeNode）到根节点（不包括根节点）的路径
def ascendTree(leafNode, prefixPath):
    if leafNode.parent is not None:
        prefixPath.append(leafNode.name)
        ascendTree(leafNode.parent, prefixPath)


# 为给定元素项生成一个条件模式基（前缀路径）。basePet表示输入的频繁项，treeNode为当前FP树中对应的第一个节点
# 函数返回值即为条件模式基condPats，用一个字典表示，键为前缀路径，值为计数值。
def findPrefixPath(basePat, headTable):
    condPats = {}
    treeNode = headTable[basePat][1]
    while treeNode != None:
        prefixPath = []
        ascendTree(treeNode, prefixPath)
        if len(prefixPath) > 1:
            condPats[frozenset(prefixPath[1:])] = treeNode.count
        treeNode = treeNode.nodeLink
    return condPats


# 遍历频繁项，生成每个频繁项的条件FP树和条件FP树的频繁项，这样每个频繁项与他条件FP树的频繁项都构成了频繁项集
# preFix:一个空集合（set([])），将在函数中用于保存当前前缀。
# freqItemList：一个空列表（[]），将用来储存生成的频繁项集。
def mineTree(inTree, headerTable, minSup, preFix, freqItemList):
    # 对频繁项按出现的数量进行排序进行排序
    sorted_headerTable = sorted(headerTable.items(),
                                key=lambda p: p[1][0])  # 返回重新排序的列表。每个元素是一个元组，[（key,[num,treeNode],()）
    bigL = [v[0] for v in sorted_headerTable]  # 获取频繁项
    for basePat in bigL:
        newFreqSet = preFix.copy()  # 新的频繁项集
        newFreqSet.add(basePat)  # 当前前缀添加一个新元素
        freqItemList.append(frozenset(newFreqSet))  # 所有的频繁项集列表
        condPattBases = findPrefixPath(basePat, headerTable)  # 获取条件模式基。
        myCondTree, myHead = createTree(condPattBases, minSup)  # 创建条件FP树

        if myHead is not None:
            mineTree(myCondTree, myHead, minSup, newFreqSet, freqItemList)  # 递归直到不再有元素


# 生成最大关联规则
# L包含所有频繁项
# support_data为相应支持度数据
def generate_big_rules(L, support_data, min_conf):
    L1 = set()
    L2 = set()
    L3 = set()
    L4 = []
    for item in L:
        if len(item) == 1:
            L1.add(item)
        if len(item) == 2:
            L2.add(item)
        if len(item) == 3:
            L3.add(item)
    L4.append(L1)
    L4.append(L2)
    L4.append(L3)
    big_rule_list = []
    sub_set_list = []
    for i in range(0, len(L4)):
        for freq_set in L4[i]:
            for sub_set in sub_set_list:
                # 判断sub_set是否在freq_set中
                if sub_set.issubset(freq_set):
                    conf = support_data[freq_set] / support_data[freq_set - sub_set]
                    big_rule = (freq_set - sub_set, sub_set, conf)
                    if conf >= min_conf and big_rule not in big_rule_list:
                        # print freq_set-sub_set, " => ", sub_set, "conf: ", conf
                        big_rule_list.append(big_rule)
            sub_set_list.append(freq_set)
    return big_rule_list, L4


# 生成支持度数据
def getSupport_data(data_set, freqItems):
    support_data = {}
    item_count = {}
    # 进行计数操作，判断元素是否被包含在原始数据集中，是就+1
    for t in data_set:
        for item in freqItems:
            if item.issubset(t):  # 判断item集合的所有元素是否都包含在t中
                if item not in item_count:
                    item_count[item] = 1
                else:
                    item_count[item] += 1
    for item1 in item_count:
        support_data[item1] = item_count[item1]
    return support_data


if __name__ == '__main__':
    minSup = 2
    simpDat = loadSimpDat()  # 加载数据集
    initSet = createInitSet(simpDat)  # 转化为符合格式的事务集
    myFPtree, myHeaderTab = createTree(initSet, minSup)  # 形成FP树
    print("FP树：")
    myFPtree.disp()  # 打印树
    freqItems = []  # 用于存储频繁项集
    mineTree(myFPtree, myHeaderTab, minSup, set([]), freqItems)  # 获取频繁项集
    support_data = getSupport_data(simpDat, freqItems)
    big_rules_list, freqItems = generate_big_rules(freqItems, support_data, min_conf=0.8)
    i = 0
    for Lk in freqItems:
        i = i + 1
        print("=" * 50)
        print("frequent " + str(i) + "-itemsets\t\t支持度")
        print("=" * 50)
        for freq_set in Lk:
            print(freq_set, support_data[freq_set])
    print()
    print("关联规则：")
    for item in big_rules_list:
        print(item[0], "=>", item[1], "conf: ", item[2])
